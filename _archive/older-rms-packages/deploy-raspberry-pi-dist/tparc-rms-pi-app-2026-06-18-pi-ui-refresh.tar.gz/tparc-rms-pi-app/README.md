# TP-ARC RMS Raspberry Pi App

This folder packages the Project HORIZON TP-ARC Remote Monitoring System as a
small Raspberry Pi service.

Copy this folder to the Raspberry Pi, then run:

```bash
cd app
sudo bash install.sh
```

The installer places:

| Path | Purpose |
| --- | --- |
| `/opt/tparc-rms/` | App launcher and virtual environment. |
| `/etc/tparc-rms/tparc-rms.env` | Runtime configuration. |
| `/var/lib/tparc-rms/` | Runtime extraction folder and SQLite database. |
| `/etc/systemd/system/tparc-rms.service` | Systemd service. |

After install:

```bash
sudo systemctl status tparc-rms
journalctl -u tparc-rms -f
```

Open:

```text
http://<raspberry-pi-ip>:5000/login
```

Default bootstrap users:

| Username | Password | Role |
| --- | --- | --- |
| `tparc` | `tparc0322` | `admin` |
| `operator` | `change-me-operator` | `operator` |
| `viewer` | `change-me-viewer` | `viewer` |

Change these from Settings before field or shared-network use.

## Configure

Edit:

```bash
sudo nano /etc/tparc-rms/tparc-rms.env
sudo systemctl restart tparc-rms
```

Common settings:

```bash
TPARC_SERIAL_PORT=/dev/ttyACM0
TPARC_PORT=5000
TPARC_SESSION_MINUTES=30
TPARC_RMS_KILL_ENABLED=0
```

## Uninstall

```bash
sudo bash uninstall.sh
```

By default, uninstall keeps `/var/lib/tparc-rms` so telemetry and user data are
not deleted accidentally. To remove data too:

```bash
sudo bash uninstall.sh --purge-data
```
